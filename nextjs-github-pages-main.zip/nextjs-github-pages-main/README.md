# Next.js Github Pages

![Github Pages](https://github.com/gregrickaby/nextjs-github-pages/workflows/github%20pages/badge.svg)

Deploy a Next.js app to Github Pages with Github Actions.

- **[View the deployed app](https://gregrickaby.github.io/nextjs-github-pages/)**
- **[Read the blog post](https://gregrickaby.blog/article/nextjs-github-pages)**
